# SARA Orchestrator#
#
# Coordinates the Four SARA reasoning agents:
# AURA, NEXA, LYRA, and ITHRA.

from typing import Dict

from app.agents.aura import analyze_case as analyze_aura
from app.agents.nexa import analyze_case as analyze_nexa
from app.agents.lyra import analyze_case as analyze_lyra
from app.agents.ithra import analyze_case as analyze_ithra

from app.core.schemas import AgentAnalysis

def run_agents(case_text: str) -> Dict[str, AgentAnalysis]:
    """
    Run all four SARA agents on the same biomedical case.

    Returns:
        A dictionary containing the analysis from each agent.
    """

    if not case_text or not case_text.strip():
        raise ValueError("Case text cannot be empty.")
    
    results = {}

    print("\n========== SARA AGENT ANALYSIS ==========\n")

    print("Running AURA...")
    results["AURA"] = analyze_aura(case_text)
    print("AURA analysis complete.\n")

    print("Running NEXA...")
    results["NEXA"] = analyze_nexa(case_text)
    print("NEXA analysis complete.\n")

    print("Running LYRA...")
    results["LYRA"] = analyze_lyra(case_text)
    print("LYRA analysis complete.\n")

    print("Running ITHRA...")
    results["ITHRA"] = analyze_ithra(case_text)
    print("ITHRA analysis complete.\n")

    return results

def orchestrate(case_text: str) -> Dict[str, AgentAnalysis]:
    """
    Main orchestration entry point.

    Currently this stage:

    Case
      ↓
    AURA
    NEXA
    LYRA
    ITHRA
      ↓
    Combined agent analyses

    Debate and consensus will be added in the next stage.
    """

    return run_agents(case_text)