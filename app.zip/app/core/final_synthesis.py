import json

from app.services.llm import generate_response


def synthesize_final_result(
    analyses: dict,
    debates: dict,
    consensus: dict
) -> dict:
    """
    Build the final SARA diagnostic synthesis from:
    - Individual agent analyses
    - Multi-agent debate results
    - Consensus result
    """

    prompt = f"""
You are SARA's Final Synthesis Engine.

Your task is to combine the outputs of four specialized AI agents,
their debate results, and the final consensus into one structured
clinical reasoning summary.

IMPORTANT:
- Do NOT invent patient information.
- Do NOT claim a definitive diagnosis.
- Clearly distinguish the leading hypothesis from alternatives.
- Preserve uncertainty and unresolved disagreements.
- Base every conclusion only on the information provided.
- This is a clinical reasoning system, not a medical diagnosis tool.

================ AGENT ANALYSES ================

{json.dumps(analyses, indent=2)}

================ DEBATE RESULTS ================

{json.dumps(debates, indent=2)}

================ CONSENSUS ================

{json.dumps(consensus, indent=2)}

=================================================

Return ONLY valid JSON using exactly this structure:

{{
    "primary_clinical_direction": "",
    "confidence": 0,
    "reasoning": [
        "",
        "",
        ""
    ],
    "supporting_findings": [
        "",
        ""
    ],
    "alternative_hypotheses": [
        {{
            "name": "",
            "reason": ""
        }}
    ],
    "recommended_investigations": [
        "",
        ""
    ],
    "unresolved_questions": [
        "",
        ""
    ],
    "agent_confidence": {{
        "AURA": 0,
        "NEXA": 0,
        "LYRA": 0,
        "ITHRA": 0
    }},
    "consensus_score": 0,
    "agreement_score": 0,
    "consensus_reached": false,
    "clinical_caution": ""
}}

Rules:
- confidence, consensus_score and agreement_score must be numbers from 0 to 100.
- consensus_reached must be true or false.
- reasoning must explain WHY the primary direction was selected.
- supporting_findings must contain findings directly supported by the case.
- alternative_hypotheses must contain plausible alternatives identified by the agents.
- recommended_investigations must come from the missing-information/workup discussed by the agents.
- unresolved_questions must preserve important uncertainty from the debate.
- clinical_caution must explicitly state that this is an AI-assisted clinical reasoning output and not a definitive diagnosis.
"""

    response = generate_response(prompt, json_mode=True)

    try:
        return json.loads(response)

    except json.JSONDecodeError as exc:
        raise RuntimeError(
            f"Final synthesis returned invalid JSON:\n{response}"
        ) from exc