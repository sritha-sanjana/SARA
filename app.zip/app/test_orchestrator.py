from app.orchestrator import orchestrate

case = """
A 32-year-old woman presents with progressive fatigue, shortness of breath, and muscle weakness over several months. Symptoms worsen after physical activity.

Laboratory investigations show elevated creatine kinase (CK) and mild anemia.

There is no known history of trauma or recent infection.
"""

results = orchestrate(case)

print("\n========== ORCHESTRATOR ANALYSIS RESULT ==========\n")

for agent, analysis in results.items():
    print(f"\n{'='*20} {agent} {'='*20}")

    print("\nKey Findings:")
    for item in analysis.key_findings:
        print("-", item)

    print("\nPatterns:")
    for item in analysis.patterns:
        print("-", item)

    print("\nHypotheses:")
    for hypothesis in analysis.hypotheses:
        print(f"\nName: {hypothesis.name}")
        print(f"Likelihood: {hypothesis.likelihood}")

    print("\nConfidence:")
    print(analysis.confidence)